import os
from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")


def get_db_connection():
    """Connect using environment variables; works locally and on hosting."""
    return mysql.connector.connect(
        host=os.environ.get("DB_HOST", "localhost"),
        user=os.environ.get("DB_USER", "root"),
        password=os.environ.get("DB_PASSWORD", ""),
        database=os.environ.get("DB_NAME", "cricket_tournament"),
        port=int(os.environ.get("DB_PORT", "3306"))
    )


def query_db(sql, params=None, fetch=True):
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(sql, params or ())
        if fetch:
            return cursor.fetchall()
        conn.commit()
        return cursor.lastrowid
    finally:
        if cursor:
            cursor.close()
        if conn and conn.is_connected():
            conn.close()


@app.route("/")
def dashboard():
    try:
        teams = query_db("SELECT COUNT(*) AS n FROM teams")[0]["n"]
        players = query_db("SELECT COUNT(*) AS n FROM players")[0]["n"]
        matches = query_db("SELECT COUNT(*) AS n FROM matches")[0]["n"]
        upcoming = query_db("""
            SELECT m.match_id, t1.team_name AS team1, t2.team_name AS team2,
                   m.match_date, m.venue, m.status
            FROM matches m
            JOIN teams t1 ON t1.team_id = m.team1_id
            JOIN teams t2 ON t2.team_id = m.team2_id
            WHERE m.status = 'Scheduled'
            ORDER BY m.match_date LIMIT 5
        """)
        return render_template("index.html", teams=teams, players=players,
                               matches=matches, upcoming=upcoming)
    except Error as e:
        return render_template("setup.html", error=str(e))


@app.route("/teams", methods=["GET", "POST"])
def teams_page():
    if request.method == "POST":
        name = request.form.get("team_name", "").strip()
        captain = request.form.get("captain", "").strip()
        coach = request.form.get("coach", "").strip()
        if not name:
            flash("Team name is required.", "error")
        else:
            try:
                query_db("INSERT INTO teams (team_name, captain, coach) VALUES (%s,%s,%s)",
                         (name, captain or None, coach or None), fetch=False)
                flash("Team added successfully.", "success")
                return redirect(url_for("teams_page"))
            except Error as e:
                flash(f"Could not add team: {e}", "error")
    try:
        teams = query_db("SELECT * FROM teams ORDER BY team_name")
        return render_template("teams.html", teams=teams)
    except Error as e:
        return render_template("setup.html", error=str(e))


@app.route("/players", methods=["GET", "POST"])
def players_page():
    if request.method == "POST":
        name = request.form.get("player_name", "").strip()
        age = request.form.get("age") or None
        role = request.form.get("role", "").strip()
        team_id = request.form.get("team_id") or None
        try:
            query_db("""INSERT INTO players (player_name, age, role, team_id)
                        VALUES (%s,%s,%s,%s)""",
                     (name, age, role or None, team_id), fetch=False)
            flash("Player added successfully.", "success")
            return redirect(url_for("players_page"))
        except Error as e:
            flash(f"Could not add player: {e}", "error")
    try:
        players = query_db("""SELECT p.*, t.team_name FROM players p
                              JOIN teams t ON p.team_id=t.team_id
                              ORDER BY p.player_name""")
        teams = query_db("SELECT team_id, team_name FROM teams ORDER BY team_name")
        return render_template("players.html", players=players, teams=teams)
    except Error as e:
        return render_template("setup.html", error=str(e))


@app.route("/players/delete/<int:player_id>", methods=["POST"])
def delete_player(player_id):
    try:
        query_db("DELETE FROM players WHERE player_id=%s", (player_id,), fetch=False)
        flash("Player deleted.", "success")
    except Error as e:
        flash(f"Could not delete player: {e}", "error")
    return redirect(url_for("players_page"))


@app.route("/matches", methods=["GET", "POST"])
def matches_page():
    if request.method == "POST":
        team1 = request.form.get("team1_id")
        team2 = request.form.get("team2_id")
        match_date = request.form.get("match_date")
        venue = request.form.get("venue", "").strip()
        if team1 == team2:
            flash("Choose two different teams.", "error")
        else:
            try:
                query_db("""INSERT INTO matches (team1_id, team2_id, match_date, venue)
                            VALUES (%s,%s,%s,%s)""",
                         (team1, team2, match_date, venue or None), fetch=False)
                flash("Match scheduled.", "success")
                return redirect(url_for("matches_page"))
            except Error as e:
                flash(f"Could not schedule match: {e}", "error")
    try:
        matches = query_db("""
            SELECT m.*, t1.team_name AS team1, t2.team_name AS team2,
                   tw.team_name AS winner
            FROM matches m
            JOIN teams t1 ON m.team1_id=t1.team_id
            JOIN teams t2 ON m.team2_id=t2.team_id
            LEFT JOIN teams tw ON m.winner_id=tw.team_id
            ORDER BY m.match_date
        """)
        teams = query_db("SELECT team_id, team_name FROM teams ORDER BY team_name")
        return render_template("matches.html", matches=matches, teams=teams)
    except Error as e:
        return render_template("setup.html", error=str(e))


@app.route("/scores", methods=["GET", "POST"])
def scores_page():
    if request.method == "POST":
        match_id = request.form.get("match_id")
        team_id = request.form.get("team_id")
        runs = request.form.get("runs", "0")
        wickets = request.form.get("wickets", "0")
        overs = request.form.get("overs", "0")
        try:
            query_db("""INSERT INTO scores (match_id, team_id, runs, wickets, overs)
                        VALUES (%s,%s,%s,%s,%s)
                        ON DUPLICATE KEY UPDATE runs=VALUES(runs),
                        wickets=VALUES(wickets), overs=VALUES(overs)""",
                     (match_id, team_id, runs, wickets, overs), fetch=False)
            flash("Score saved.", "success")
            return redirect(url_for("scores_page"))
        except Error as e:
            flash(f"Could not save score: {e}", "error")
    try:
        matches = query_db("""
            SELECT m.match_id, m.match_date, t1.team_name AS team1, t2.team_name AS team2
            FROM matches m JOIN teams t1 ON m.team1_id=t1.team_id
            JOIN teams t2 ON m.team2_id=t2.team_id ORDER BY m.match_date
        """)
        teams = query_db("SELECT team_id, team_name FROM teams ORDER BY team_name")
        scores = query_db("""
            SELECT s.*, t.team_name, m.match_date
            FROM scores s JOIN teams t ON s.team_id=t.team_id
            JOIN matches m ON s.match_id=m.match_id
            ORDER BY m.match_date DESC, s.runs DESC
        """)
        return render_template("scores.html", matches=matches, teams=teams, scores=scores)
    except Error as e:
        return render_template("setup.html", error=str(e))


@app.route("/standings")
def standings_page():
    try:
        standings = query_db("""
            SELECT t.team_id, t.team_name,
                COUNT(DISTINCT CASE WHEN m.status='Completed' THEN m.match_id END) AS played,
                SUM(CASE WHEN m.status='Completed' AND m.winner_id=t.team_id THEN 1 ELSE 0 END) AS wins,
                SUM(CASE WHEN m.status='Completed' AND m.winner_id IS NOT NULL
                          AND m.winner_id<>t.team_id THEN 1 ELSE 0 END) AS losses,
                SUM(CASE WHEN m.status='Completed' AND m.winner_id IS NULL THEN 1 ELSE 0 END) AS no_results,
                SUM(CASE WHEN m.status='Completed' AND m.winner_id=t.team_id THEN 2 ELSE 0 END) AS points
            FROM teams t
            LEFT JOIN matches m ON t.team_id=m.team1_id OR t.team_id=m.team2_id
            GROUP BY t.team_id, t.team_name
            ORDER BY points DESC, wins DESC, t.team_name
        """)
        return render_template("standings.html", standings=standings)
    except Error as e:
        return render_template("setup.html", error=str(e))


@app.route("/results/<int:match_id>", methods=["POST"])
def set_result(match_id):
    winner_id = request.form.get("winner_id") or None
    status = request.form.get("status", "Completed")
    try:
        query_db("UPDATE matches SET winner_id=%s, status=%s WHERE match_id=%s",
                 (winner_id, status, match_id), fetch=False)
        flash("Match result updated.", "success")
    except Error as e:
        flash(f"Could not update result: {e}", "error")
    return redirect(url_for("matches_page"))


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
