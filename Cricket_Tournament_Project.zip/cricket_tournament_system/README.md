# Cricket Tournament Management System

A DBMS mini project built with Python Flask, MySQL, HTML, and CSS.

## Features
- Dashboard counts for teams, players, and matches
- Add and list teams
- Add and delete players
- Schedule matches
- Enter or update scorecards
- Record match results
- Tournament points table

## Requirements
- Python 3.10+
- MySQL Server
- VS Code (recommended)

## Run locally on Windows

1. Open this folder in VS Code.
2. In MySQL Workbench or your MySQL query window, run all of `schema.sql`.
3. Open the VS Code terminal in this folder and run:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```

4. Set environment variables in the same PowerShell terminal (replace the password):

   ```powershell
   $env:DB_HOST="localhost"
   $env:DB_PORT="3306"
   $env:DB_USER="root"
   $env:DB_PASSWORD="YOUR_MYSQL_PASSWORD"
   $env:DB_NAME="cricket_tournament"
   $env:SECRET_KEY="change-this-to-a-long-random-value"
   ```

5. Start the app:

   ```powershell
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

If PowerShell blocks virtual-environment activation, use `.\.venv\Scripts\python.exe -m pip install -r requirements.txt` and `.\.venv\Scripts\python.exe app.py` instead.

## Important for deployment

A hosted Flask website cannot connect to the MySQL server on your laptop using `localhost`. For a public live website, provision a hosted MySQL database with a reachable host, then configure these environment variables in your hosting provider:
- `DB_HOST`
- `DB_PORT`
- `DB_USER`
- `DB_PASSWORD`
- `DB_NAME`
- `SECRET_KEY`

Do not upload your password, `.env` file, or private database credentials to GitHub. `schema.sql` includes illustrative sample cricket records; update them as needed.

## GitHub

Create a new empty repository on GitHub, then run these commands in this folder:

```bash
git init
git add .
git commit -m "Build cricket tournament management system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your actual GitHub repository URL.

## Deployment outline

1. Push this project to GitHub.
2. Create a hosted MySQL database with a provider that permits connections from your web host.
3. Import `schema.sql` into that hosted database (if the provider does not allow `CREATE DATABASE`, remove the first two lines and select the database in the provider's console first).
4. Create a web service on Render (or another Python host) and connect your GitHub repository.
5. Build command: `pip install -r requirements.txt`
6. Start command: `gunicorn app:app`
7. Add the database environment variables in the host dashboard.
8. Deploy; the host will provide a public URL.

A GitHub repository link is not the same as a deployed live website URL.
