CREATE DATABASE IF NOT EXISTS cricket_tournament;
USE cricket_tournament;

CREATE TABLE IF NOT EXISTS teams (
    team_id INT PRIMARY KEY AUTO_INCREMENT,
    team_name VARCHAR(50) NOT NULL UNIQUE,
    captain VARCHAR(50),
    coach VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS players (
    player_id INT PRIMARY KEY AUTO_INCREMENT,
    player_name VARCHAR(50) NOT NULL,
    age INT,
    role VARCHAR(30),
    team_id INT NOT NULL,
    CONSTRAINT fk_players_team FOREIGN KEY (team_id)
        REFERENCES teams(team_id)
);

CREATE TABLE IF NOT EXISTS matches (
    match_id INT PRIMARY KEY AUTO_INCREMENT,
    team1_id INT NOT NULL,
    team2_id INT NOT NULL,
    match_date DATE NOT NULL,
    venue VARCHAR(100),
    status ENUM('Scheduled','Completed','Abandoned') NOT NULL DEFAULT 'Scheduled',
    winner_id INT NULL,
    CONSTRAINT chk_different_teams CHECK (team1_id <> team2_id),
    CONSTRAINT fk_match_team1 FOREIGN KEY (team1_id) REFERENCES teams(team_id),
    CONSTRAINT fk_match_team2 FOREIGN KEY (team2_id) REFERENCES teams(team_id),
    CONSTRAINT fk_match_winner FOREIGN KEY (winner_id) REFERENCES teams(team_id)
);

CREATE TABLE IF NOT EXISTS scores (
    score_id INT PRIMARY KEY AUTO_INCREMENT,
    match_id INT NOT NULL,
    team_id INT NOT NULL,
    runs INT NOT NULL DEFAULT 0,
    wickets INT NOT NULL DEFAULT 0,
    overs DECIMAL(4,1) NOT NULL DEFAULT 0,
    CONSTRAINT chk_runs CHECK (runs >= 0),
    CONSTRAINT chk_wickets CHECK (wickets BETWEEN 0 AND 10),
    CONSTRAINT chk_overs CHECK (overs >= 0 AND overs <= 20),
    CONSTRAINT fk_scores_match FOREIGN KEY (match_id) REFERENCES matches(match_id),
    CONSTRAINT fk_scores_team FOREIGN KEY (team_id) REFERENCES teams(team_id),
    CONSTRAINT uq_match_team UNIQUE (match_id, team_id)
);

INSERT IGNORE INTO teams (team_name, captain, coach) VALUES
('SRH', 'Pat Cummins', 'Daniel Vettori'),
('CSK', 'Ruturaj Gaikwad', 'Stephen Fleming'),
('RCB', 'Rajat Patidar', 'Andy Flower'),
('MI', 'Hardik Pandya', 'Mahela Jayawardene');

INSERT IGNORE INTO players (player_name, age, role, team_id) VALUES
('Abhishek Sharma', 26, 'Batsman', 1),
('Pat Cummins', 33, 'Bowler', 1),
('Travis Head', 32, 'Batsman', 1),
('Ruturaj Gaikwad', 29, 'Batsman', 2),
('MS Dhoni', 45, 'Wicketkeeper', 2),
('Rajat Patidar', 32, 'Batsman', 3),
('Virat Kohli', 37, 'Batsman', 3),
('Hardik Pandya', 33, 'All-rounder', 4),
('Rohit Sharma', 39, 'Batsman', 4);

INSERT IGNORE INTO matches (match_id, team1_id, team2_id, match_date, venue, status, winner_id)
VALUES (1, 1, 2, '2026-10-10', 'Hyderabad', 'Completed', 1),
       (2, 3, 4, '2026-10-11', 'Mumbai', 'Completed', 3),
       (3, 1, 3, '2026-10-20', 'Bengaluru', 'Scheduled', NULL);

INSERT IGNORE INTO scores (match_id, team_id, runs, wickets, overs) VALUES
(1, 1, 185, 5, 20.0),
(1, 2, 160, 8, 20.0),
(2, 3, 195, 4, 20.0),
(2, 4, 175, 7, 20.0);
